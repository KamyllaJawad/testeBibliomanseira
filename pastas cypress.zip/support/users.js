const users = {
    ADMIN: {
        USER: 'xunda',
        PASSWORD: 'teste123'
    }
}
export default users