const enviroments = {
    URL: 'http://localhost/biblioteca'
}
export default enviroments