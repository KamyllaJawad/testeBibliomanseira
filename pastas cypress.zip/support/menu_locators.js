const menus = {
    PRINCIPAL: '/principal.php'
}
export default menus