const login_locator = {
    USER: '#fUsuario',
    PASSWORD: '#fSenha',
    BTN_LOGIN: '#btnEntrar'
}
export default login_locator