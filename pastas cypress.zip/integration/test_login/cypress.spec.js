import env from '../../support/enviroments'
import user from '../../support/users'
import menu from '../../support/menu_locators'

describe('Teste de Login de Usuário', () => {
    beforeEach(function() {
        cy.login(env.URL, user.ADMIN.USER, user.ADMIN.PASSWORD)
    })

    it('Listar tela principal', () => {
        cy.visit(env.URL + menu.PRINCIPAL)
    })

})